# Ride Assistant Android project

## Build APK using GitHub Actions (phone-friendly)

1. Upload the contents of this ZIP to a GitHub repository (not the ZIP file itself).
2. Open the repository's **Actions** tab.
3. Select **Build Ride Assistant Android APK**.
4. Tap **Run workflow** (or push/commit to the `main` branch).
5. When the workflow finishes successfully, open that run and download the **RideAssistant-Debug-APK** artifact.
6. Extract the downloaded artifact ZIP; it contains `app-debug.apk`. Install it on your Android phone. Android may ask you to allow installs from that source.

## Local build

Requires JDK 17 and Gradle 8.7 installed:

```sh
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Important limitations

This project loads a hosted web app in a WebView and includes an accessibility-service scaffold. A successful APK build does **not** guarantee the hosted web app, fare detection, or ride acceptance works correctly. Test carefully and follow each ride platform's rules. This project does not include the Gradle Wrapper, so the provided GitHub Actions workflow installs Gradle 8.7 directly.
