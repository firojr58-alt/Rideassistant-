package com.rideassistant.nativebridge

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject
import java.util.regex.Pattern

/**
 * RideAccessibilityService
 *
 * Scans accessibility window hierarchies of authorized ride platforms.
 * Intercepts ride popups, parses fare, distance, and pickup metrics,
 * notifies the WebView/Angular layer, and triggers click on the ACCEPT button.
 */
class RideAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "RideAccessibilitySvc"
        var instance: RideAccessibilityService? = null
        
        // Target ride app package names
        val TARGET_PACKAGES = setOf(
            "com.ubercab.driver",
            "com.olacabs.partner",
            "com.rapido.captain",
            "org.movingtech.nammyatri"
        )
    }

    private val farePattern = Pattern.compile("(?:₹|INR|Rs\\.?)\\s*(\\d+(?:\\.\\d+)?)", Pattern.CASE_INSENSITIVE)
    private val distancePattern = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s*(?:km|kms)", Pattern.CASE_INSENSITIVE)

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        val info = AccessibilityServiceInfo().apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                         AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                    AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                    AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            packageNames = TARGET_PACKAGES.toTypedArray()
            notificationTimeout = 20 // Ultra-fast 20ms dispatch
        }
        serviceInfo = info
        Log.i(TAG, "RideAccessibilityService connected & monitoring target packages.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !TARGET_PACKAGES.contains(event.packageName?.toString())) return

        val rootNode = rootInActiveWindow ?: return
        try {
            inspectWindowForIncomingRide(rootNode, event.packageName.toString())
        } finally {
            // Recycle rootNode in older APIs or let GC reclaim
        }
    }

    private fun inspectWindowForIncomingRide(root: AccessibilityNodeInfo, packageName: String) {
        val isRapido = packageName.contains("rapido")
        val appName = when {
            isRapido -> "Rapido Captain"
            packageName.contains("uber") -> "Uber Driver"
            packageName.contains("ola") -> "Ola Partner"
            else -> "Partner"
        }

        var detectedFare: Double? = null
        var detectedRideKm: Double? = null
        var detectedPickupKm: Double? = null
        var detectedVehicleType: String = "Auto"
        var acceptButtonNode: AccessibilityNodeInfo? = null

        fun traverse(node: AccessibilityNodeInfo?) {
            if (node == null) return

            val text = node.text?.toString() ?: node.contentDescription?.toString()
            val viewId = node.viewIdResourceName?.lowercase() ?: ""

            if (!text.isNullOrBlank()) {
                // Rapido vehicle type detection
                if (isRapido) {
                    if (text.contains("bike", ignoreCase = true)) detectedVehicleType = "Bike"
                    if (text.contains("auto", ignoreCase = true)) detectedVehicleType = "Auto"
                    if (text.contains("cab", ignoreCase = true)) detectedVehicleType = "Cab"
                }

                // Parse fare
                val fareMatcher = farePattern.matcher(text)
                if (fareMatcher.find() && detectedFare == null) {
                    detectedFare = fareMatcher.group(1)?.toDoubleOrNull()
                }

                // Parse distance
                val distMatcher = distancePattern.matcher(text)
                if (distMatcher.find()) {
                    val dist = distMatcher.group(1)?.toDoubleOrNull()
                    if (dist != null) {
                        if (text.contains("pickup", ignoreCase = true) || text.contains("away", ignoreCase = true)) {
                            detectedPickupKm = dist
                        } else if (detectedRideKm == null) {
                            detectedRideKm = dist
                        }
                    }
                }

                // Check for Accept button in Rapido Captain or others
                if (text.equals("ACCEPT", ignoreCase = true) || 
                    text.equals("ACCEPT ORDER", ignoreCase = true) ||
                    text.equals("ACCEPT RIDE", ignoreCase = true) ||
                    text.contains("Tap to accept", ignoreCase = true) ||
                    viewId.contains("btn_accept") ||
                    viewId.contains("accept_order")) {
                    if (node.isClickable) {
                        acceptButtonNode = node
                    } else if (node.parent?.isClickable == true) {
                        acceptButtonNode = node.parent
                    }
                }
            }

            for (i in 0 until node.childCount) {
                traverse(node.getChild(i))
            }
        }

        traverse(root)

        if (detectedFare != null && detectedRideKm != null) {
            val rideId = "RAPIDO_${System.currentTimeMillis()}"
            val payload = JSONObject().apply {
                put("id", rideId)
                put("sourceApp", appName)
                put("rapidoVehicleType", detectedVehicleType)
                put("totalFare", detectedFare)
                put("rideDistanceKm", detectedRideKm)
                put("pickupDistanceKm", detectedPickupKm ?: 1.0)
                put("timestamp", System.currentTimeMillis())
            }

            // Stash node reference for instantaneous click execution
            ActiveRideCache.activeNode = acceptButtonNode
            ActiveRideCache.activeRideId = rideId

            // Dispatch to WebView Angular app
            RideBridgeActivity.dispatchRideToWeb(payload.toString())
        }
    }

    fun performClickOnRide(rideId: String): Boolean {
        if (ActiveRideCache.activeRideId == rideId && ActiveRideCache.activeNode != null) {
            val node = ActiveRideCache.activeNode
            val clicked = node?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
            Log.d(TAG, "Executed ACTION_CLICK on ride $rideId: $clicked")
            ActiveRideCache.activeNode = null
            return clicked
        }
        return false
    }

    override fun onInterrupt() {
        Log.w(TAG, "RideAccessibilityService interrupted")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }
}

object ActiveRideCache {
    var activeNode: AccessibilityNodeInfo? = null
    var activeRideId: String? = null
}
