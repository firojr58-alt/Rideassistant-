package com.rideassistant.nativebridge

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import org.json.JSONObject

class RideBridgeActivity : AppCompatActivity() {

    companion object {
        @SuppressLint("StaticFieldLeak")
        var currentWebView: WebView? = null

        fun dispatchRideToWeb(jsonString: String) {
            currentWebView?.post {
                currentWebView?.evaluateJavascript(
                    "if(window.onNativeRideDetected) { window.onNativeRideDetected('$jsonString'); }",
                    null
                )
            }
        }
    }

    private lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        currentWebView = webView

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.allowFileAccess = false
        settings.databaseEnabled = true

        // Register the Javascript Interface named "AndroidRideBridge"
        webView.addJavascriptInterface(AndroidRideBridgeInterface(this), "AndroidRideBridge")

        // Load the local or hosted Angular PWA URL
        webView.loadUrl("https://ais-dev-pqw3jtuqogzi3oymswniwn-418368491374.asia-northeast1.run.app")
    }

    override fun onDestroy() {
        super.onDestroy()
        currentWebView = null
    }
}

/**
 * Exposed JavaScript Interface accessible from Angular: window.AndroidRideBridge
 */
class AndroidRideBridgeInterface(private val context: Context) {

    @JavascriptInterface
    fun isAvailable(): Boolean = true

    @JavascriptInterface
    fun startAccessibilityMonitor(configJson: String): Boolean {
        // Starts foreground background service and syncs filters
        val serviceIntent = Intent(context, RideOverlayService::class.java).apply {
            putExtra("CONFIG", configJson)
            action = RideOverlayService.ACTION_START
        }
        context.startForegroundService(serviceIntent)
        return true
    }

    @JavascriptInterface
    fun stopAccessibilityMonitor(): Boolean {
        val serviceIntent = Intent(context, RideOverlayService::class.java).apply {
            action = RideOverlayService.ACTION_STOP
        }
        context.startService(serviceIntent)
        return true
    }

    @JavascriptInterface
    fun acceptRide(rideId: String): Boolean {
        return RideAccessibilityService.instance?.performClickOnRide(rideId) ?: false
    }

    @JavascriptInterface
    fun rejectRide(rideId: String): Boolean {
        ActiveRideCache.activeNode = null
        ActiveRideCache.activeRideId = null
        return true
    }

    @JavascriptInterface
    fun getNativeStatus(): String {
        val json = JSONObject().apply {
            put("isAvailable", true)
            put("accessibilityServiceRunning", RideAccessibilityService.instance != null)
            put("overlayPermissionGranted", android.provider.Settings.canDrawOverlays(context))
            put("batteryOptimizationsIgnored", true)
            put("gpsEnabled", true)
            put("lastPingMs", System.currentTimeMillis())
        }
        return json.toString()
    }
}
