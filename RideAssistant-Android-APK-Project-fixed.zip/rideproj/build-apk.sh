#!/bin/bash
echo "Building Ride Assistant Android APK..."
chmod +x ./gradlew
./gradlew assembleDebug
echo ""
echo "Build complete! APK located at:"
echo "app/build/outputs/apk/debug/app-debug.apk"
echo ""
echo "To install on your phone via USB debugging:"
echo "adb install -r app/build/outputs/apk/debug/app-debug.apk"
