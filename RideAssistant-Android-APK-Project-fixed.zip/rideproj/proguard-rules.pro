# Ride Assistant ProGuard rules. No custom rules are currently required.
